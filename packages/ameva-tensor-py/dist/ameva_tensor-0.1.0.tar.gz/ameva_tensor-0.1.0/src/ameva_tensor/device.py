"""
device.py — WebGPU 디바이스 초기화 및 상태 관리

H-03 Fix: 무성(silent) CPU 폴백 완전 제거.
  - WebGPU 초기화 실패 시 조용히 CPU로 전환하는 로직 삭제.
  - 이 라이브러리의 핵심 가치는 WebGPU이다. 초기화에 실패하면
    명시적 예외를 던져 사용자에게 즉각 알린다.
  - CPU 텐서(`device="cpu"`)는 명시적으로 요청할 때만 사용 가능.

L-04 Fix: is_pyodide(), init_bridge()를 bridge.py에서 올바르게 임포트.
"""
from typing import Any, Optional
from .bridge import is_pyodide, init_bridge
from .errors import AMEVATensorWebGPUUnavailableError

_CURRENT_DEVICE: str = "cpu"


async def init(experimental_zero_copy: bool = False) -> None:
    """
    WebGPU 엔진을 초기화한다.

    H-03: 초기화 실패 시 CPU 폴백 없이 AMEVATensorWebGPUUnavailableError를 던진다.
    사용자는 try/except로 직접 처리해야 한다.

    Raises:
        AMEVATensorWebGPUUnavailableError: Pyodide 환경이 아니거나 WebGPU 초기화 실패 시.
        RuntimeError: JS 브릿지 연결 실패 시.
    """
    global _CURRENT_DEVICE

    if not is_pyodide():
        raise AMEVATensorWebGPUUnavailableError(
            "AMEVA-Tensor requires a Pyodide (browser/WASM) environment. "
            "Non-browser Python runtimes are not supported for GPU execution."
        )

    # JS 브릿지 초기화 (실패하면 예외 전파 — 폴백 없음)
    res = init_bridge({"experimental_zero_copy": experimental_zero_copy})
    if hasattr(res, "then"):
        import asyncio
        await res

    _CURRENT_DEVICE = "gpu"


def is_available() -> bool:
    """현재 WebGPU가 초기화되어 있는지 반환한다."""
    return _CURRENT_DEVICE == "gpu"


def current_device() -> str:
    """현재 기본 디바이스 문자열을 반환한다 ('gpu' 또는 'cpu')."""
    return _CURRENT_DEVICE
