class AMEVATensorError(Exception):
    pass

class AMEVATensorShapeError(AMEVATensorError):
    pass

class AMEVATensorDTypeError(AMEVATensorError):
    pass

class AMEVATensorDeviceError(AMEVATensorError):
    pass

class AMEVATensorDisposedError(AMEVATensorError):
    pass

class AMEVATensorWebGPUUnavailableError(AMEVATensorError):
    pass
