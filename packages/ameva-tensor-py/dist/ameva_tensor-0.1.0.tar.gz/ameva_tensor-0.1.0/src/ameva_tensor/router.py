"""
router.py — [DEPRECATED]

M-04 Fix: should_use_gpu / ensure_same_device 로직이 ops.py로 통합됨.
  - _ensure_same_device: ops.py의 _ensure_same_device()
  - _should_use_gpu: ops.py의 _should_use_gpu()

이 파일은 하위 호환성을 위해 유지되지만, 내부 ops.py에서 직접 구현을 사용한다.
외부 코드에서 이 모듈을 임포트하지 말 것.
"""
from typing import Tuple, Any
from .errors import AMEVATensorDeviceError


def should_use_gpu(op_name: str, inputs: Tuple[Any, ...], **kwargs) -> bool:
    """
    M-04 Deprecated: ops.py의 _should_use_gpu()를 사용하세요.
    모든 피연산자가 GPU일 때만 True를 반환합니다.
    """
    return all(getattr(inp, "device", "cpu") == "gpu" for inp in inputs)


def ensure_same_device(inputs: Tuple[Any, ...]) -> None:
    """
    M-04 Deprecated: ops.py의 _ensure_same_device()를 사용하세요.
    """
    if not inputs:
        return
    first_device = getattr(inputs[0], "device", "cpu")
    for inp in inputs[1:]:
        if getattr(inp, "device", "cpu") != first_device:
            raise AMEVATensorDeviceError(
                f"Mixed device operation: '{first_device}' vs "
                f"'{getattr(inp, 'device', 'cpu')}'. "
                "Use .to('gpu') or .to('cpu') to move tensors explicitly."
            )


def calibrate() -> None:
    raise NotImplementedError("Calibration is not implemented.")
