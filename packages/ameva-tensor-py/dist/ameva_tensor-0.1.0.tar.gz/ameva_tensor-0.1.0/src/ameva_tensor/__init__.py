"""
__init__.py — ameva_tensor 패키지 공개 API

M-07 Fix: `from .errors import *` wildcard import 제거.
  → 내부 에러 클래스를 명시적으로 나열하여 의도치 않은 심볼 노출 차단.
  사용자는 `ameva_tensor.AMEVATensorShapeError` 등으로 직접 접근 가능.
"""
from .device import init, is_available, current_device
from .ops import tensor, random, matmul, relu, add, mul, transpose, to_numpy, to_numpy_async, dispose
from .tensor import Tensor
from .errors import (
    AMEVATensorError,
    AMEVATensorShapeError,
    AMEVATensorDTypeError,
    AMEVATensorDeviceError,
    AMEVATensorDisposedError,
    AMEVATensorWebGPUUnavailableError,
)

__version__ = "0.1.0"

__all__ = [
    # 초기화
    "init",
    "is_available",
    "current_device",
    # 텐서 생성
    "tensor",
    "random",
    "Tensor",
    # 연산
    "matmul",
    "relu",
    "add",
    "mul",
    "transpose",
    # 유틸
    "to_numpy",
    "to_numpy_async",
    "dispose",
    # 에러
    "AMEVATensorError",
    "AMEVATensorShapeError",
    "AMEVATensorDTypeError",
    "AMEVATensorDeviceError",
    "AMEVATensorDisposedError",
    "AMEVATensorWebGPUUnavailableError",
    # 메타
    "__version__",
]
