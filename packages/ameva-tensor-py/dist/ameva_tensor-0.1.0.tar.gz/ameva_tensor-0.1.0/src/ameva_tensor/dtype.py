SUPPORTED_DTYPES = {"float32"}

def validate_dtype(dtype: str) -> str:
    if dtype not in SUPPORTED_DTYPES:
        raise ValueError(f"Unsupported dtype: {dtype}. Only 'float32' is supported currently.")
    return dtype
