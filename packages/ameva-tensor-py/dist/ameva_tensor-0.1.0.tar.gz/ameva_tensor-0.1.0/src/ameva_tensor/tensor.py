from typing import Any, Tuple, Optional, List
import numpy as np
from .errors import AMEVATensorDisposedError, AMEVATensorShapeError, AMEVATensorDeviceError


def build_lazy_topo(root: 'Tensor') -> List['Tensor']:
    """위상 정렬: 레이지 그래프에서 루트까지의 노드를 의존성 순서로 반환"""
    topo: List['Tensor'] = []
    visited: set = set()

    def _build(v: 'Tensor') -> None:
        vid = id(v)
        if vid not in visited:
            visited.add(vid)
            for p in getattr(v, '_parents', ()):
                _build(p)
            topo.append(v)

    _build(root)
    return topo

_gc_queue: set = set()

def flush_gc() -> None:
    if not _gc_queue:
        return
    handles = list(_gc_queue)
    _gc_queue.clear()
    try:
        from .bridge import js_dispose_batch
        js_dispose_batch(handles)
    except Exception:
        pass


class _HandleCell:
    """
    C-01 Fix: weakref.finalize가 생성 시점의 handle(None)을 캡처하는 버그 방지.
    handle을 mutable container에 담아 finalize 시점에 항상 최신 값을 참조하도록 한다.
    Reference Cell 패턴 (JAX/Linen에서 사용하는 동일 패턴).
    """
    __slots__ = ('handle',)

    def __init__(self, handle: Optional[str]) -> None:
        self.handle = handle


class Tensor:
    def __init__(
        self,
        shape: Tuple[int, ...],
        dtype: str,
        device: str,
        requires_grad: bool = False,
        handle: Optional[str] = None,
        data: Optional[np.ndarray] = None,
        op: Optional[str] = None,
        parents: tuple = (),
        op_params: Optional[list] = None
    ):
        self.shape = shape
        self.dtype = dtype
        self.device = device
        self.requires_grad = requires_grad
        self.grad: Optional['Tensor'] = None

        # --- 내부 상태 ---
        # C-01: handle을 _HandleCell로 감싸 finalizer가 항상 최신 handle을 참조
        self._handle_cell = _HandleCell(handle)
        self._data = data
        self._disposed = False

        # --- Autograd 상태 ---
        self._ctx: Optional[Any] = None
        self._parents: tuple = parents
        self._op_cls: Optional[Any] = None

        # --- Lazy 그래프 메타데이터 (L-02: _parents와 통합, 이중 저장 제거) ---
        self._lazy_op = op
        self._lazy_params = op_params

        # RAII: GPU 텐서만 finalize 등록 (C-01: _handle_cell 참조로 수정)
        if self.device == "gpu":
            import weakref
            weakref.finalize(self, Tensor._finalize_buffer, self._handle_cell)

    @property
    def _handle(self) -> Optional[str]:
        return self._handle_cell.handle

    @_handle.setter
    def _handle(self, value: Optional[str]) -> None:
        # C-01: handle 업데이트는 항상 cell을 통해 → finalizer도 최신 값 참조
        self._handle_cell.handle = value

    @staticmethod
    def _finalize_buffer(cell: '_HandleCell') -> None:
        """
        C-01: cell.handle은 realize() 이후 실제 핸들로 채워진 최신 값.
        M-06: 즉시 dispose하지 않고 큐에 모아 Batch GC를 수행한다.
        """
        handle = cell.handle
        if handle is not None:
            _gc_queue.add(handle)

    def _check_disposed(self) -> None:
        if self._disposed:
            raise AMEVATensorDisposedError("Cannot access a disposed Tensor.")

    # -------------------------------------------------------------------------
    # C-02 Fix: realize()를 동기적 그래프 제출로 명확히 재설계.
    # js_execute_graph는 WebGPU command를 submit하고 즉시 핸들 맵을 반환한다.
    # (GPU 연산은 비동기로 진행) → 이후 numpy_async()에서 mapBufferAsync가
    # submit 이후의 GPU 큐를 대기하므로 race는 발생하지 않는다.
    # 단, realize()는 "그래프 제출"이지 "GPU 완료 대기"가 아님을 명시.
    # -------------------------------------------------------------------------
    def realize(self) -> None:
        """레이지 그래프를 단일 FFI 호출로 GPU에 제출한다 (동기 submit, 비동기 실행)."""
        flush_gc()
        if self.device == "cpu" or self._handle is not None:
            return

        topo = build_lazy_topo(self)
        from .graph import GraphBuilder
        builder = GraphBuilder()

        node_id_map: dict = {}
        for v in topo:
            if v._handle is not None:
                nid = builder.add_load(v.shape, v._handle)
                node_id_map[id(v)] = nid
            elif v._lazy_op == 'upload':
                nid = builder.add_upload(v.shape, v._data)
                node_id_map[id(v)] = nid
            else:
                in_ids = [node_id_map[id(p)] for p in v._parents]
                nid = builder.add_op(v._lazy_op, v.shape, in_ids, v._lazy_params)
                node_id_map[id(v)] = nid

        instructions, inputs = builder.compile()
        from .bridge import js_execute_graph

        out_handles = js_execute_graph(instructions, inputs)

        # M-02 Fix: 핸들이 None인 노드를 silently skip하지 않고 에러 발생
        for v in topo:
            nid = node_id_map[id(v)]
            h = out_handles.get(str(nid)) or out_handles.get(nid)
            if h is None:
                raise AMEVATensorDeviceError(
                    f"Failed to retrieve valid tensor handle from JS for node {nid} (op={v._lazy_op!r})."
                )
            v._handle = h  # C-01: _HandleCell을 통해 setter 호출
            if v._lazy_op == 'upload':
                v._data = None  # 호스트 메모리 즉시 해제

    def numpy(self) -> np.ndarray:
        """CPU 텐서의 데이터를 동기적으로 반환한다."""
        self._check_disposed()
        if self.device == "cpu":
            if self._data is None:
                raise AMEVATensorDisposedError("CPU tensor data has been released.")
            return self._data
        else:
            raise AMEVATensorDeviceError(
                "GPU tensor readback is asynchronous. Use: data = await tensor.numpy_async()"
            )

    async def numpy_async(self) -> np.ndarray:
        """GPU 텐서 데이터를 Zero-Copy로 비동기 읽어온다."""
        self._check_disposed()
        if self.device == "cpu":
            if self._data is None:
                raise AMEVATensorDisposedError("CPU tensor data has been released.")
            return self._data

        # 1. 레이지 그래프를 GPU에 제출 (동기 submit)
        self.realize()

        from .bridge import js_map_async, js_read_mapped_into
        # 2. GPU 큐 완료 대기 + staging 버퍼 맵핑 (진짜 비동기 대기)
        await js_map_async(self._handle)

        # 3. WASM 힙에 직접 읽어들이기 (Zero-Copy)
        out = np.empty(self.shape, dtype=np.float32)
        js_read_mapped_into(self._handle, out)

        return out

    def dispose(self) -> None:
        """텐서와 연결된 GPU 버퍼를 즉시 해제한다."""
        if self._disposed:
            return
        if self.device == "gpu" and self._handle is not None:
            from .bridge import js_dispose
            js_dispose(self._handle)
            self._handle = None  # cell 업데이트 → finalizer 중복 호출 방지

        self._data = None
        self._disposed = True
        self._lazy_op = None
        self._parents = ()
        self._ctx = None

    # -------------------------------------------------------------------------
    # C-08 Fix: backward() 구현
    # autograd DAG를 역방향 위상 탐색하여 연쇄 법칙 적용
    # -------------------------------------------------------------------------
    def backward(self, gradient: Optional['Tensor'] = None) -> None:
        """역전파를 수행한다. gradient 미지정 시 ones_like(self)로 초기화."""
        self._check_disposed()
        if not self.requires_grad:
            raise RuntimeError("Cannot call backward() on a tensor that does not require grad.")

        from .autograd import build_topological_sort
        from .ops import ones_like

        # 스칼라 손실이 아닐 때 gradient 시드 필요
        if gradient is None:
            if self.shape != () and self.shape != (1,) and self.shape != (1, 1):
                gradient = ones_like(self)
            else:
                gradient = ones_like(self)

        # grad 맵 초기화
        grads: dict = {id(self): gradient}

        topo = build_topological_sort(self)
        # 역순 탐색
        for v in reversed(topo):
            if not getattr(v, 'requires_grad', False):
                continue
            if id(v) not in grads:
                continue

            grad_out = grads[id(v)]

            if v._ctx is None or v._op_cls is None:
                # 리프 노드 → grad 누적
                if v.grad is None:
                    v.grad = grad_out
                else:
                    from .ops import add
                    v.grad = add(v.grad, grad_out)
                continue

            # backward 호출
            grad_inputs = v._op_cls.backward(v._ctx, grad_out)
            if not isinstance(grad_inputs, tuple):
                grad_inputs = (grad_inputs,)

            for parent, g in zip(v._parents, grad_inputs):
                if not getattr(parent, 'requires_grad', False) or g is None:
                    continue
                pid = id(parent)
                if pid in grads:
                    from .ops import add
                    grads[pid] = add(grads[pid], g)
                else:
                    grads[pid] = g

        # 리프 노드에 grad 저장
        for v in topo:
            if getattr(v, 'requires_grad', False) and v._ctx is None and id(v) in grads:
                if v.grad is None:
                    v.grad = grads[id(v)]
                else:
                    from .ops import add
                    v.grad = add(v.grad, grads[id(v)])

    def relu(self) -> 'Tensor':
        self._check_disposed()
        from .ops import relu
        return relu(self)

    def matmul(self, other: 'Tensor') -> 'Tensor':
        self._check_disposed()
        from .ops import matmul
        return matmul(self, other)

    def __matmul__(self, other: 'Tensor') -> 'Tensor':
        return self.matmul(other)

    def __add__(self, other: 'Tensor') -> 'Tensor':
        self._check_disposed()
        from .ops import add
        return add(self, other)

    def __mul__(self, other: 'Tensor') -> 'Tensor':
        self._check_disposed()
        from .ops import mul
        return mul(self, other)

    def __repr__(self) -> str:
        if self._disposed:
            return "<AMEVA Tensor (disposed)>"
        return (
            f"<AMEVA Tensor shape={self.shape}, dtype={self.dtype}, "
            f"device={self.device}, requires_grad={self.requires_grad}, "
            f"handle={self._handle}>"
        )
