from typing import Any, Tuple, Optional, List
import contextlib

_grad_mode = True

@contextlib.contextmanager
def no_grad():
    global _grad_mode
    prev = _grad_mode
    _grad_mode = False
    try:
        yield
    finally:
        _grad_mode = prev

class Context:
    def __init__(self):
        self.saved_tensors = ()
    
    def save_for_backward(self, *args):
        self.saved_tensors = args

class Function:
    @classmethod
    def apply(cls, *args, **kwargs):
        # Only build graph if any input requires_grad and grad_mode is on
        requires_grad = _grad_mode and any(
            (hasattr(a, 'requires_grad') and a.requires_grad) for a in args
        )
        
        ctx = Context()
        
        # Unpack tensors to underlying handles or arrays for forward pass if needed,
        # but for our ops, we pass Tensor objects directly to the ops functions.
        result = cls.forward(ctx, *args, **kwargs)
        
        if requires_grad:
            result.requires_grad = True
            result._ctx = ctx
            result._op_cls = cls
            result._parents = tuple(a for a in args if hasattr(a, 'requires_grad') and isinstance(a, type(result)))
            
        return result

    @staticmethod
    def forward(ctx: Context, *args, **kwargs) -> Any:
        raise NotImplementedError

    @staticmethod
    def backward(ctx: Context, grad_output: Any) -> Tuple[Any, ...]:
        raise NotImplementedError

def build_topological_sort(root) -> List[Any]:
    topo = []
    visited = set()
    
    def _build(v):
        if v not in visited:
            visited.add(v)
            if hasattr(v, '_parents') and v._parents:
                for parent in v._parents:
                    _build(parent)
            topo.append(v)
            
    _build(root)
    return topo
