import json
from typing import Any, Dict, List, Tuple

class GraphBuilder:
    def __init__(self):
        self.nodes: List[Dict[str, Any]] = []
        self.inputs: List[Any] = []
        self.next_id = 1
        
    def alloc_id(self) -> int:
        idx = self.next_id
        self.next_id += 1
        return idx
        
    def add_upload(self, shape: Tuple[int, ...], data: Any = None) -> int:
        node_id = self.alloc_id()
        self.nodes.append({"op": "upload", "id": node_id, "shape": list(shape)})
        if data is not None:
            self.inputs.append(data)
        return node_id
        
    def add_load(self, shape: Tuple[int, ...], handle: str) -> int:
        node_id = self.alloc_id()
        self.nodes.append({"op": "load", "id": node_id, "shape": list(shape), "handle": handle})
        return node_id
        
    def add_op(self, op_name: str, shape: Tuple[int, ...], in_ids: List[int], params: List[int] = None) -> int:
        node_id = self.alloc_id()
        node = {"op": op_name, "id": node_id, "shape": list(shape), "in": in_ids}
        if params is not None:
            node["params"] = params
        self.nodes.append(node)
        return node_id

    def compile(self) -> Tuple[str, List[Any]]:
        return json.dumps(self.nodes), self.inputs
