"""
bridge.py — Python ↔ TypeScript FFI 미들웨어

C-03 Fix:
  - to_js import 정리 (미사용 제거)
  - inputs를 JS로 넘기기 전에 pyodide.ffi.to_js로 명시적 변환하여
    PyProxy 생명주기 및 타입 불일치 문제 원천 차단
  - batch dispose 구현 (M-06 Fix)

L-04 Fix:
  - is_pyodide(), init_bridge() 함수 정의 추가
    (device.py에서 import하는 함수들이 실제로 없었음)
"""
from typing import Any, List, Optional, Dict
import sys

def is_pyodide() -> bool:
    """현재 런타임이 Pyodide(브라우저 WASM) 환경인지 확인한다."""
    return sys.platform == 'emscripten'


def get_js_core() -> Any:
    """globalThis.amevaTensor 바인딩을 반환한다."""
    import js
    if not hasattr(js.globalThis, 'amevaTensor'):
        raise RuntimeError(
            "[AMEVA Tensor] WebGPU core not found on globalThis.amevaTensor. "
            "Ensure registerPyodideBridge() was called before init()."
        )
    return js.globalThis.amevaTensor


def init_bridge(config: Dict = None) -> Any:
    """JS 단의 WebGPU 엔진을 초기화한다."""
    core = get_js_core()
    return core.init(config)


async def js_map_async(handle: str) -> None:
    core = get_js_core()
    await core.mapBufferAsync(handle)


def js_read_mapped_into(handle: str, arr: Any) -> None:
    core = get_js_core()
    core.readMappedInto(handle, arr)


def js_dispose(handle: str) -> None:
    """단일 핸들의 GPU 버퍼를 해제한다."""
    if handle is None:
        return
    try:
        core = get_js_core()
        core.dispose(handle)
    except Exception:
        pass


def js_dispose_batch(handles: list) -> None:
    if not handles:
        return
    try:
        core = get_js_core()
        if hasattr(core, 'disposeBatch'):
            from pyodide.ffi import to_js
            core.disposeBatch(to_js(handles))
        else:
            for h in handles:
                core.dispose(h)
    except Exception:
        pass


def js_execute_graph(instructions_json: str, inputs: List[Any]) -> Any:
    """
    레이지 연산 그래프를 단일 FFI 호출로 GPU에 제출한다.
    """
    core = get_js_core()
    from pyodide.ffi import to_js
    js_inputs = to_js([memoryview(inp) for inp in inputs], dict_converter=None)
    res = core.executeGraph(instructions_json, js_inputs)
    return res.to_py() if hasattr(res, 'to_py') else res
